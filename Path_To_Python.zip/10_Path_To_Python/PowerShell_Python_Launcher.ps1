# Created by Sam Escolas in 2016. Edited & Upgraded by Kevin Russell & Shane Johnson on 1/24/2019

#Global Variables (These cannot be changed)

[int]$Global:MenuItem = 0;
[int]$Global:MenuStart = 0;
[int]$Global:MenuEnd = 0;

<#
    For functions 2-28, files will need to be re-located according to the filepath
#>
FUNCTION Run($show_menu=$true)
{
    If($show_menu)
    
    {Write-Host @"
    
Choose one of the following to run:
        
1`tProject 1
2`tProject 2
3`tProject 3
32`tMultiple
33`tCancel
99`tExit

        
"@

}

    if ($Global:MenuItem -eq 0)
    {
        $Global:MenuItem = Read-Host ">>> ";
    }

    Switch($Global:MenuItem)
    {
        {$_ -Eq "1" -or $_ -Match "time"}
        {
            Start-Process powershell.exe "& python '$env:WORK\python\Bin\Project_1\myproject1.py'"# -WindowStyle Minimized;
        }
        {$_ -Eq "2" -or $_ -Match "corn"}
        {
            Start-Process powershell.exe "& python '$env:WORK\python\Bin\Project_2\myproject2.py'" -WindowStyle Minimized;
        }
        {$_ -Eq "3" -or $_ -Match "sbc"}
        {
            Start-Process powershell.exe "& python '$env:WORK\python\Bin\Project_3\myproject3.py'" -WindowStyle Minimized;
        }
        {$_ -Eq "32" -or $_ -Match "multi" -or $_ -Eq "M"}
        {
            $Global:MenuStart = Read-Host "Start Num ";
            if ($Global:MenuStart -eq $null -or [string]::IsNullOrEmpty($Global:MenuStart) -or $Global:MenuStart -lt 1)
            {
                $Global:MenuStart = 0;
                $Global:MenuItem = 0;
                run($false);
            }

            $Global:MenuEnd = Read-Host "End Num ";
            if ($Global:MenuEnd -eq $null -or [string]::IsNullOrEmpty($Global:MenuEnd) -or $Global:MenuEnd -gt 98)
            {
                $Global:MenuStart = 0;
                $Global:MenuEnd = 0;
                $Global:MenuItem = 0;
                run($false);
            }

            $Global:MenuItem = $Global:MenuStart;
            Do
            {
                $val=run($false);
                $Global:MenuStart++;
                $Global:MenuItem = $Global:MenuStart;
            }
            While($Global:MenuStart -lt $Global:MenuEnd -and $val -ne "^C")
            If($val -ne "^C") { Write-Host "Calm down..."; }

            $Global:MenuStart = 0;
            $Global:MenuEnd = 0;
        }

        {$_ -Eq "33" -or $_ -Match "cancel"}
        {
            Return '^C';
        }

        {$_ -Eq "99" -or $_ -Match "exit"}
        {
            Exit
        }

        Default
        {
	    if ($Global:MenuStart -eq $null -or [string]::IsNullOrEmpty($Global:MenuStart) -or $Global:MenuStart -lt 1)
            {
                $Global:MenuItem = 0;
                run($false)
            }
        }
    }
    
}

Run -show_menu $true